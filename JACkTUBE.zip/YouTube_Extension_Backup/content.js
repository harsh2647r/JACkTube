// Function to remove all YouTube ads
function removeAds() {
    const adSelectors = [
        '.ytp-ad-module',  // Video ads
        '.ytp-ad-player-overlay',  // Overlay ads
        '.ytp-ad-text',  // Ad text
        'ytd-ad-slot-renderer',  // In-between ads
        '#player-ads',  // Player ads
        '.ytp-ad-image-overlay',  // Image overlay ads
        '.ytp-ad-overlay-container',  // Banner ads
        'ytd-display-ad-renderer',  // Display ads
        'ytd-promoted-video-renderer',  // Promoted videos
        'ytd-companion-slot-renderer'  // Sidebar ads
    ];
    
    adSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(ad => ad.remove());
    });

    // Skip skippable ads instantly
    const skipButton = document.querySelector('.ytp-ad-skip-button');
    if (skipButton) {
        skipButton.click();
    }
}

// Run function when the page loads and on changes
const observer = new MutationObserver(removeAds);
observer.observe(document.body, { childList: true, subtree: true });

// Also run once on load
window.addEventListener('load', removeAds);

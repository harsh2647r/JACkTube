chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    return { cancel: true };
  },
  { urls: [
      "*://www.youtube.com/api/stats/ads*",
      "*://www.youtube.com/get_midroll_info*",
      "*://www.youtube.com/pagead/*",
      "*://www.youtube.com/youtubei/v1/advertiser*",
      "*://www.google.com/pagead/*",
      "*://googleads.g.doubleclick.net/*",
      "*://static.doubleclick.net/*",
      "*://securepubads.g.doubleclick.net/*"
  ] },
  ["blocking"]
);
